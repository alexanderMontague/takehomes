import { put, takeLatest, all } from 'redux-saga/effects';
//import { someSaga } from './someSaga';
//import { otherSaga } from './otherSaga';

export default function* rootSaga() {
  //yield all([someSaga(), otherSaga()]);
}
