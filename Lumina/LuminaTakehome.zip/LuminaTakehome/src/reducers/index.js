import { combineReducers } from "redux";
// import someReducer from './someReducer';
// import otherReducer from './otherReducer';

//const rootReducer = combineReducers({
// someReducer,
// otherReducer
//});
const rootReducer = () => {};

export default rootReducer;
