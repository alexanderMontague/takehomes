# Lumina Interview Takehome

### Notes

- I used my own boilerplate that I have created for starting projects or doing takehomes
- It is based off of CRA
- Top stories seemed to be very recent, why the hours calculation is funny
- No actual source listed in the API, had to hack it from the URL

### To Run

- CD into the correct project `cd LuminaApp`
- install dependencies using preferred method `yarn` or `npm i`
- run the application (will automatically open in browser) `yarn start` or `npm start`
